package edu.lawrence.reviews.services;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.lawrence.reviews.entities.Restaurant;
import edu.lawrence.reviews.interfaces.dtos.AvgRating;
import edu.lawrence.reviews.interfaces.dtos.RestaurantDTO;
import edu.lawrence.reviews.repositories.RestaurantRepository;
import edu.lawrence.reviews.repositories.ReviewRepository;

@Service
public class RestaurantService {
	
	@Autowired
	RestaurantRepository restaurantRepository;
	
	@Autowired
	ReviewRepository reviewRepository;
	
	public String save(RestaurantDTO restaurant) {
		Restaurant newRestaurant = new Restaurant(restaurant);
		restaurantRepository.save(newRestaurant);
		return newRestaurant.getRestaurantid().toString();
	}
	
	public List<Restaurant> findAll() {
		return restaurantRepository.findAll();
	}
	
	public List<Restaurant> findByFoodtype(String foodtype) {
		return restaurantRepository.findByFoodtype(foodtype);
	}
	
	public Restaurant findByRestaurantid(UUID restaurantid) {
		Optional<Restaurant> maybeRestaurant = restaurantRepository.findByRestaurantid(restaurantid);
		if(!maybeRestaurant.isPresent())
			return null;
		Restaurant restaurant = maybeRestaurant.get();

		return restaurant;
	}
	
	public int numRating(UUID restaurantid) {
		return reviewRepository.countByRestaurantid(restaurantid);
	}
	
	public AvgRating avgRating(UUID restaurantid) {
		AvgRating result = new AvgRating();
		result.setAvgFood(reviewRepository.avgFood(restaurantid));
		result.setAvgAmbience(reviewRepository.avgAmbience(restaurantid));
		result.setAvgPrice(reviewRepository.avgPrice(restaurantid));
		return result;
	}
	
}
