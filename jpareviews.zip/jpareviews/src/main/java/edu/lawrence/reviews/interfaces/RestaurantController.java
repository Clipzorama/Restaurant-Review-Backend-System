package edu.lawrence.reviews.interfaces;

import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.lawrence.reviews.entities.Restaurant;
import edu.lawrence.reviews.interfaces.dtos.AvgRating;
import edu.lawrence.reviews.interfaces.dtos.RestaurantDTO;
import edu.lawrence.reviews.services.RestaurantService;

@RestController
@RequestMapping("/restaurants")
@CrossOrigin(origins = "*")
public class RestaurantController {

	private RestaurantService restaurantService;
	
	public RestaurantController(RestaurantService restaurantService) {
        this.restaurantService = restaurantService;
    }
	
	@PostMapping
    public ResponseEntity<String> save(@RequestBody RestaurantDTO restaurant) {
		String key = restaurantService.save(restaurant);
        return ResponseEntity.ok().body(key);
	}
	
	@GetMapping()
	public ResponseEntity<List<Restaurant>> findAll() {
		List<Restaurant> result = restaurantService.findAll();
		return ResponseEntity.ok().body(result);
	}
	
	@GetMapping("/foodtype/{type}")
	public ResponseEntity<List<Restaurant>> allRestaurantsByFoodtype(@PathVariable("String") String foodtype) {
		List<Restaurant> result = restaurantService.findByFoodtype(foodtype);
		return ResponseEntity.ok().body(result);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Restaurant> findByRestaurantid(@PathVariable("id") UUID restaurantid) {
		Restaurant result = restaurantService.findByRestaurantid(restaurantid);
		if (result == null)
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		return ResponseEntity.ok().body(result);
	}
	
	@GetMapping("/{id}/quality")
	public ResponseEntity<AvgRating> avgRating(@PathVariable("id") UUID restaurantid) {
		AvgRating key = restaurantService.avgRating(restaurantid);
		if (key == null) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(key);
        } else {
        }
        return ResponseEntity.ok().body(key);
	}
	
	@GetMapping("/{id}/quantity")
	public ResponseEntity<Integer> numRating(@PathVariable("id") UUID restaurantid) {
		int result = restaurantService.numRating(restaurantid);
		return ResponseEntity.ok().body(result);
	}
}
