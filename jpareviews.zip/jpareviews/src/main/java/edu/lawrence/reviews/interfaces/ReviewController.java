package edu.lawrence.reviews.interfaces;

import java.util.List;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.lawrence.reviews.entities.Review;
import edu.lawrence.reviews.interfaces.dtos.ReviewDTO;
import edu.lawrence.reviews.services.ReviewService;

@RestController
@RequestMapping("/reviews")
@CrossOrigin(origins = "*")
public class ReviewController {
	
	private ReviewService reviewService;
	
	public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }
	
	@PostMapping
    public ResponseEntity<String> save(@RequestBody ReviewDTO review) {
		String key = reviewService.save(review);
        return ResponseEntity.ok().body(key);
	}
	
	@GetMapping("/{restaurantid}")
	public ResponseEntity<List<Review>> findByReviewid(@PathVariable("restaurantid") UUID restaurantid) {
		List<Review> result = reviewService.findByRestaurantid(restaurantid);
		return ResponseEntity.ok().body(result);
	}
	
}
