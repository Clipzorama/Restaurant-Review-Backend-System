package edu.lawrence.reviews.repositories;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.lawrence.reviews.entities.Response;

public interface ResponseRepository extends JpaRepository<Response,UUID>{
	@Query("select r from Response r where r.review.reviewid=:reviewId")
	List<Response> findByReviewid(UUID reviewId);
}
