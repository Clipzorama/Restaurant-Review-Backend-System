package edu.lawrence.reviews.services;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.lawrence.reviews.entities.Response;
import edu.lawrence.reviews.entities.Review;
import edu.lawrence.reviews.entities.User;
import edu.lawrence.reviews.interfaces.dtos.ResponseDTO;
import edu.lawrence.reviews.repositories.ResponseRepository;
import edu.lawrence.reviews.repositories.ReviewRepository;
import edu.lawrence.reviews.repositories.UserRepository;

@Service
public class ResponseService {
	
	@Autowired
	ResponseRepository responseRepository;
	
	@Autowired
	ReviewRepository reviewRepository;

	@Autowired
	UserRepository userRepository;
		
	public String save(ResponseDTO response) {
		Response newResponse = new Response(response);

		Optional<User> maybeUser = userRepository.findById(UUID.fromString(response.getUserid()));
		if(!maybeUser.isPresent())
			return "Invalid user";
		User user = maybeUser.get();

		Optional<Review> maybeReview = reviewRepository.findById(UUID.fromString(response.getReviewid()));
		if(!maybeReview.isPresent())
			return "Invalid restaurant";
		Review review = maybeReview.get();

		newResponse.setUser(user);
		newResponse.setReview(review);
		responseRepository.save(newResponse);
		return newResponse.getResponseid().toString();
	}

	public List<Response> findByReviewid(UUID reviewid) {
		return responseRepository.findByReviewid(reviewid);
	}

}
