package edu.lawrence.reviews.repositories;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.lawrence.reviews.entities.Restaurant;

public interface RestaurantRepository extends JpaRepository<Restaurant,UUID>{
	
	// Finds all restaurants
	List<Restaurant> findAll();
	
	// Find restaurants by foodType.
	List<Restaurant> findByFoodtype(String foodtype);
	
	// Finds a restaurant by its ID using a custom query
	@Query("select r from Restaurant r where r.restaurantid=:restaurantid")
	Optional<Restaurant> findByRestaurantid(UUID restaurantid);
	
}
