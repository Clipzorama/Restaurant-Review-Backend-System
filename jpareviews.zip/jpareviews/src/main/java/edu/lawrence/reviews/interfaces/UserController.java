package edu.lawrence.reviews.interfaces;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.lawrence.reviews.services.UserService;
import edu.lawrence.reviews.entities.User;
import edu.lawrence.reviews.interfaces.dtos.UserDTO;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "*")
public class UserController {

	private UserService us;
    
    public UserController(UserService us) {
        this.us = us;
    }

    @PostMapping("/login")
    public ResponseEntity<String> checkLogin(@RequestBody UserDTO user) {
        User result = us.findByNameAndPassword(user.getName(), user.getPassword());
        if (result == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid user name or password");
        }
        return ResponseEntity.ok().body(result.getUserid().toString());
    }
    
    @PostMapping
    public ResponseEntity<String> save(@RequestBody UserDTO user) {
        if (user.getName().isBlank() || user.getPassword().isBlank()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Empty user name or password");
        }

        String key = us.save(user);
        if (key.equals("Duplicate")) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("User with this name already exists");
        } else if (key.equals("Error")) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Can not generate key");
        }
        return ResponseEntity.ok().body(key);
    }
}