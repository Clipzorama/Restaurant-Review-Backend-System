package edu.lawrence.reviews.interfaces.dtos;

import edu.lawrence.reviews.entities.Review;

public class ReviewDTO {
	
	private String reviewid;
	private String restaurantid;
	private String userid;
	private String posted;
	private int food;
	private int ambience;
	private int price;
	private String comments;
	
	public ReviewDTO() {}

	public ReviewDTO(Review core) {
		reviewid = core.getReviewid().toString();
		restaurantid = core.getRestaurant().getRestaurantid().toString();
		userid = core.getUser().getUserid().toString();
		posted = core.getPosted().toString();
		food = core.getFood();
		ambience = core.getAmbience();
		price = core.getPrice();
		comments = core.getComments();
	}
	
	public String getReviewid() {
		return reviewid;
	}
	public void setReviewid(String reviewid) {
		this.reviewid = reviewid;
	}
	public String getRestaurantid() {
		return restaurantid;
	}
	public void setRestaurantid(String restaurantid) {
		this.restaurantid = restaurantid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPosted() {
		return posted;
	}
	public void setPosted(String posted) {
		this.posted = posted;
	}
	public int getFood() {
		return food;
	}
	public void setFood(int food) {
		this.food = food;
	}
	public int getAmbience() {
		return ambience;
	}
	public void setAmbience(int ambience) {
		this.ambience = ambience;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
}