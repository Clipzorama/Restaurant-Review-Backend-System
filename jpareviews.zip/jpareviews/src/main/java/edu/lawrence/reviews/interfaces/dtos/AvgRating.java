package edu.lawrence.reviews.interfaces.dtos;

public class AvgRating {
	private Double avgFood;
	private Double avgAmbience;
	private Double avgPrice;
	
	public AvgRating() {}
	
	public Double getAvgFood() {
		return avgFood;
	}

	public void setAvgFood(Double avgFood) {
		this.avgFood = avgFood;
	}

	public Double getAvgAmbience() {
		return avgAmbience;
	}

	public void setAvgAmbience(Double avgAmbience) {
		this.avgAmbience = avgAmbience;
	}

	public Double getAvgPrice() {
		return avgPrice;
	}

	public void setAvgPrice(Double avgPrice) {
		this.avgPrice = avgPrice;
	}
	
}
