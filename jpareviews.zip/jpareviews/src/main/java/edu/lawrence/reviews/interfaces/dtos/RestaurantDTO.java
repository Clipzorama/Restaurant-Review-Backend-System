package edu.lawrence.reviews.interfaces.dtos;

import edu.lawrence.reviews.entities.Restaurant;

public class RestaurantDTO {
	
	private String restaurantid;
	private String name;
	private String address;
	private String foodtype;
	
	public RestaurantDTO() {}
	
	public RestaurantDTO(Restaurant core) {
		restaurantid = core.getRestaurantid().toString();
		name = core.getName().toString();
		address = core.getAddress();
		foodtype = core.getFoodtype();
	}
	
	public String getRestaurantid() {
		return restaurantid;
	}
	public void setRestaurantid(String restaurantid) {
		this.restaurantid = restaurantid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getFoodtype() {
		return foodtype;
	}
	public void setFoodtype(String foodtype) {
		this.foodtype = foodtype;
	}
	
}