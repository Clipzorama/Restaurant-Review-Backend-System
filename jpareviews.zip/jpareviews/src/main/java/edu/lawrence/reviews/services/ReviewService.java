package edu.lawrence.reviews.services;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.lawrence.reviews.entities.Restaurant;
import edu.lawrence.reviews.entities.Review;
import edu.lawrence.reviews.entities.User;
import edu.lawrence.reviews.interfaces.dtos.ReviewDTO;
import edu.lawrence.reviews.repositories.RestaurantRepository;
import edu.lawrence.reviews.repositories.ReviewRepository;
import edu.lawrence.reviews.repositories.UserRepository;

@Service
public class ReviewService {
	
	@Autowired
	RestaurantRepository restaurantRepository;
	
	@Autowired
	ReviewRepository reviewRepository;
	
	@Autowired
	UserRepository userRepository;
	
	public String save(ReviewDTO review) {
		Review newReview = new Review(review);
		
		Optional<User> maybeUser = userRepository.findByUserid(UUID.fromString(review.getUserid()));
		if(!maybeUser.isPresent())
			return "Invalid User";
		User user = maybeUser.get();
		
		Optional<Restaurant> maybeRestaurant = restaurantRepository.findByRestaurantid(UUID.fromString(review.getRestaurantid()));
		if(!maybeRestaurant.isPresent())
			return "Invalid Restaurant";
		Restaurant restaurant = maybeRestaurant.get();
		
		newReview.setUser(user);
		newReview.setRestaurant(restaurant);
		reviewRepository.save(newReview);
		return newReview.getReviewid().toString();
	}
	
	public List<Review> findByRestaurantid(UUID restaurantid) {
		return reviewRepository.findByRestaurantid(restaurantid);
	}
	
}
