package edu.lawrence.reviews.interfaces.dtos;

import edu.lawrence.reviews.entities.Response;

public class ResponseDTO {
	private String responseid;
	private String reviewid;
	private String userid;
	private String responses;
	
	public ResponseDTO() {}

	public ResponseDTO (Response core) {
		responseid = core.getResponseid().toString();
		reviewid = core.getReview().getReviewid().toString();
		userid = core.getUser().toString();
		responses = core.getResponses();
	}
	
	public String getResponseid() {
		return responseid;
	}

	public void setResponseid(String responseid) {
		this.responseid = responseid;
	}
	
	public String getReviewid() {
		return reviewid;
	}
	public void setReviewid(String reviewid) {
		this.reviewid = reviewid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getResponses() {
		return responses;
	}
	public void setResponses(String responses) {
		this.responses = responses;
	}
}

