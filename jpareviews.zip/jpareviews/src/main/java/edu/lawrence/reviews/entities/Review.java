package edu.lawrence.reviews.entities;

import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import edu.lawrence.reviews.interfaces.dtos.ReviewDTO;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="reviews")
public class Review {
	
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(columnDefinition = "VARCHAR(45)")
	@JdbcTypeCode(SqlTypes.VARCHAR)
	private UUID reviewid;
	@ManyToOne
	@JoinColumn(name="restaurantid")
	private Restaurant restaurant;
	@ManyToOne
	@JoinColumn(name="userid")
	private User user;
	private LocalDateTime posted;
	private int food;
	private int ambience;
	private int price;
	private String comments;
	
	public Review() {}
    
    public Review(ReviewDTO core) {
		posted = LocalDateTime.now();
		food = core.getFood();
		ambience = core.getAmbience();
		price = core.getPrice();
		comments = core.getComments();
	}
    
	public UUID getReviewid() {
		return reviewid;
	}
	public void setReviewid(UUID reviewid) {
		this.reviewid = reviewid;
	}
	public Restaurant getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public LocalDateTime getPosted() {
		return posted;
	}
	public void setPosted(LocalDateTime posted) {
		this.posted = posted;
	}
	public int getFood() {
		return food;
	}
	public void setFood(int food) {
		this.food = food;
	}
	public int getAmbience() {
		return ambience;
	}
	public void setAmbience(int ambience) {
		this.ambience = ambience;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
}
